package com.twitterapp.pojo;

public class UserTweets {

	String emailId;
	String Tweet;

	public UserTweets() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getTweet() {
		return Tweet;
	}

	public void setTweet(String tweet) {
		Tweet = tweet;
	}

	@Override
	public String toString() {
		return "UserTweets [emailId=" + emailId + ", Tweet=" + Tweet + "]";
	}

}
