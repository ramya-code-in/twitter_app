package com.twitterapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.twitterapp.MySqlConnector;
import com.twitterapp.pojo.User;

public class AddUserDao {
	Connection connection = MySqlConnector.getConnection();

	public Boolean addNewUser(User newUser) {
		String addNewUserQuery = "insert into user(first_name, last_name,gender, email_id, dob, password,is_logged_in) values(?,?,?,?,?,?,?)";
		Boolean success = false;
		try {
			PreparedStatement statement = connection.prepareStatement(addNewUserQuery);
			statement.setString(1, newUser.getFirstName());
			statement.setString(2, newUser.getLastName());
			statement.setString(3, newUser.getGender());
			statement.setString(4, newUser.getEmailId());
			statement.setString(5, newUser.getDob());
			statement.setString(6, newUser.getPassword());
			statement.setBoolean(7, newUser.isLoggedIn);
			statement.executeUpdate();
			success = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			success = false;
		}

		return success;
	}

	public Boolean loginUserDao(String emailId, String password) {
		String checkCredentials = "Update user set is_logged_in =? where email_id=? and password=?";
		Boolean isValid = false;
		try {
			PreparedStatement statement = connection.prepareStatement(checkCredentials);
			statement.setBoolean(1, true);
			statement.setString(2, emailId);
			statement.setString(3, password);
			int resultSet = statement.executeUpdate();
			if (resultSet > 0) {
				isValid = true;
			}

		} catch (SQLException e) {
			isValid = false;
		}
		return isValid;

	}

	public Boolean resetPassword(String emailId, String password) {
		String resetQuery = "update user set password = ?, is_logged_in=? where email_id=?";
		Boolean success = false;
		PreparedStatement statement;
		try {
			statement = connection.prepareStatement(resetQuery);
			statement.setString(1, password);
			statement.setBoolean(2, true);
			statement.setString(3, emailId);
			statement.executeUpdate();
			success = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return success;

	}

	public Boolean logout(String emailId) {
		String logoutQuery = "Update user set is_logged_in=? where email_id=?";
		Boolean success = false;
		try {
			PreparedStatement statement = connection.prepareStatement(logoutQuery);
			statement.setBoolean(1, false);
			statement.setString(2, emailId);
			success = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return success;
	}
}
