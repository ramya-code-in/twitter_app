package com.twitterapp.service;

import java.util.Scanner;

import com.twitterapp.dao.AddUserDao;
import com.twitterapp.dao.TweetsDao;

public class TweetsService {

	Scanner sc = new Scanner(System.in);

	public void tweetsMenu(String emailId) {

		System.out.println("What would you like to do..?");
		System.out.println("1.Post a tweet");
		System.out.println("2.Read your tweets");
		System.out.println("3.Read all tweets");
		System.out.println("4.Update your password");
		System.out.println("5.Logout");

		int userOption = sc.nextInt();

		switch (userOption) {
		case 1:
			postTweets(emailId);
			break;

		case 2:
			readMyTweets(emailId);
			break;

		case 3:
			readAllTweets(emailId);
			break;

		case 4:
			updatePassword();
			break;

		case 5:
			logout(emailId);
			break;

		default:
			System.out.println("Please select a valid option");
			tweetsMenu(emailId);
			break;
		}
	}

	public void postTweets(String emailId) {
		TweetsDao tweetsDao = new TweetsDao();
		System.out.println("Write your tweet here and press Enter");
		sc.nextLine();
		String userTweet = sc.nextLine();
		if (tweetsDao.postTweets(emailId, userTweet)) {
			System.out.println("Nice, your post tweeted!");
			tweetsMenu(emailId);
		}

	}

	public void readMyTweets(String emailId) {
		TweetsDao tweetsDao = new TweetsDao();
		tweetsDao.viewMyTweets(emailId);
		tweetsMenu(emailId);
	}

	public void readAllTweets(String emailId) {
		TweetsDao tweetsDao = new TweetsDao();
		tweetsDao.readAllTweets();
		tweetsMenu(emailId);

	}

	public void updatePassword() {
		AddUserDao userDao = new AddUserDao();
		AddUser userService = new AddUser();
		System.out.println("Enter your Email Id");
		String emailId = sc.next();
		System.out.println("Enter old password");
		String oldPassword = sc.next();
		System.out.println("Enter new password");
		String newPassword = sc.next();
		if (!userDao.loginUserDao(emailId, oldPassword)) {
			if (userDao.resetPassword(emailId, newPassword)) {
				System.out.println("Password Updated Successfully !\n");
				tweetsMenu(emailId);
			}
		}

	}

	public void logout(String emailId) {
		AddUserDao userDao = new AddUserDao();

		if (userDao.logout(emailId)) {
			System.out.println("You have successfully logged out !");
			AddUser userService = new AddUser();
			userService.userMenu();
		}
	}

}
