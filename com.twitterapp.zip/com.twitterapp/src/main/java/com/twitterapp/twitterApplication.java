package com.twitterapp;

import java.sql.*;

import com.twitterapp.service.AddUser;

public class twitterApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AddUser home =  new AddUser();
		System.out.println("Welcome");
		System.out.println("## Please Select an option to continue ##");
		home.userMenu();
			  

	}
}


